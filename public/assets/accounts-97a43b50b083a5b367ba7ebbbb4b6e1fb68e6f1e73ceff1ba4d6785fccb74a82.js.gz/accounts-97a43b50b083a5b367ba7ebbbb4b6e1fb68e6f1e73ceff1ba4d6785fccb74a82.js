(function() {
  $(document).ready(function() {
    $('#accordion').accordion({
      collapsible: true,
      active: false
    });
    $('#accordion2').accordion({
      collapsible: true,
      active: false
    });
  });

}).call(this);
