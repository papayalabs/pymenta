$(function () {
    $('#company-logo').on('change', '#uploadLogo', function () {
        $('#submitLogo').click();
    });
});
